package music.string;

import music.playable;

public class veena implements playable {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Veena is playing");
	}

}
