package music.wind;

import music.playable;

public class saxophone implements playable {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("saxophone is playing");
	}

}
