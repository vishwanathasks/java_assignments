public class fact
{
	public static int fact(int n)
	{
		if(n==0)
			return 1;
		else
			return (n*fact(n-1));
	}
	

	public static void main(String args[])
	{
		int m=5;
		int fact=fact(m);
		System.out.println(" the factorial of number is"+" "+fact);
	}
}