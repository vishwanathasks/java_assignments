package music;
public interface playable
{
	public void play();
}



package music.string;
import music.playable;
public class veena implements playable
{
	public void play()
	{
		System.out.println("veena is playing");
	}
}

package live;
import music.playable;
import music.string.veena;
public class test
{
	public static void main(String args[])
	{
		veena v=new veena();
		v.play();
	}
}