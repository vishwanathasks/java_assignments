package live;

import music.playable;
import music.string.*;

import music.wind.*;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			veena v=new veena();
			v.play();
			saxophone s = new saxophone();
			s.play();
			playable p;
			p=new veena();
			p.play();
			p=new saxophone();
			p.play();
	}

}
/* hiii */