package music;

public interface playable {

	public void play();
}
